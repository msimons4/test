# Fairway Forge Golf

This repo is **GitHub-ready** for the Android project.

## Populate the project

1. Unzip the **v20** project locally (the full Android Studio project).
2. Copy its contents into the root of this repo (so `app/`, `gradle/`, `settings.gradle.kts`, etc. live at the repo root).
3. Ensure `app/google-services.json` matches your package `com.mathewsimons.fairwayforge`.

> If you prefer, open the project in Android Studio and use **VCS > Enable Version Control Integration** to initialize Git here, then push.

## Build locally

```bash
./gradlew assembleDebug
```

## GitHub Actions (optional)
A simple CI workflow is included to run a debug build on PRs.

## License
MIT
