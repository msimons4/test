# Fairway Forge Golf (v20)

Android Studio project (Kotlin + Jetpack Compose). Brand-ready with tutorial and pre-round hole selection.
This v20 starter compiles out-of-the-box and includes stubs for Firebase multiplayer and physics.

## Get started
1. Open in Android Studio.
2. (Optional) Add Firebase `app/google-services.json` for multiplayer.
3. Run on device or emulator.

## Build a release App Bundle
- Android Studio → Build → Generate Signed Bundle/APK → Android App Bundle (.aab)
