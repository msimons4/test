package com.mathewsimons.fairwayforge.data

import android.content.Context
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.mathewsimons.fairwayforge.model.RoomState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class MultiplayerRepository(context: Context) {
    private val db = Firebase.firestore
    private val auth = Firebase.auth

    suspend fun signInAnon(): String {
        val user = auth.currentUser ?: auth.signInAnonymously().result?.user
        return user?.uid ?: ""
    }

    fun watchRoom(code: String): Flow<RoomState> = callbackFlow {
        val sub = db.collection("rooms").document(code).addSnapshotListener { snap, _ ->
            trySend(snap?.toObject(RoomState::class.java) ?: RoomState(code = code))
        }
        awaitClose { sub.remove() }
    }

    // create/join/post-stroke methods would go here
}
