package com.mathewsimons.fairwayforge.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun StartRoundDialog(show: Boolean, defaultHoles: Int = 9, onDismiss: () -> Unit, onStart: (Int) -> Unit) {
    if (!show) return
    var choice by remember { mutableStateOf(defaultHoles) }
    var custom by remember { mutableStateOf("18") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Start Round") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("How many holes?")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(3,9,18).forEach { n ->
                        FilterChip(selected = choice==n, onClick = { choice = n }, label = { Text("$n") })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = choice==0, onClick = { choice = 0 }, label = { Text("Custom") })
                    if (choice==0) {
                        OutlinedTextField(value = custom, onValueChange = { custom = it.filter { c -> c.isDigit() }.take(2) }, label = { Text("Holes") })
                    }
                }
            }
        },
        confirmButton = { Button(onClick = { val n = if (choice==0) custom.toIntOrNull() ?: defaultHoles else choice; onStart(n.coerceIn(1,18)) }) { Text("Start") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
