package com.mathewsimons.fairwayforge.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun RoundCompleteScreen(onBackToGame: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("Round Complete") }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("GG! This screen will show totals and rematch in the full build.")
            Button(onClick = onBackToGame) { Text("Back to Game") }
        }
    }
}
