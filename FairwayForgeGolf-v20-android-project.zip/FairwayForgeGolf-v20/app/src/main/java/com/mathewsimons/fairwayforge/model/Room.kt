package com.mathewsimons.fairwayforge.model

data class RoomState(
    val code: String = "",
    val players: List<String> = emptyList(),
    val courseAsset: String = "courses/tobacco_road_like.json",
    val hole: Int = 0,
    val windAngle: Float = 0f,
    val windSpeed: Float = 0f,
    val holesToPlay: Int = 9,
    val turnPlayerId: String = "",
    val strokesP1: List<Int> = emptyList(),
    val strokesP2: List<Int> = emptyList(),
    val status: String = "open"
)
