package com.mathewsimons.fairwayforge.ui

import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.*
import com.mathewsimons.fairwayforge.data.SettingsRepository
import androidx.compose.runtime.collectAsState

@Composable
fun AppNav() {
    val nav = rememberNavController()
    val ctx = LocalContext.current
    val settings = remember { SettingsRepository(ctx) }
    val seen by settings.tutorialSeenFlow().collectAsState(initial = false)

    val start = if (!seen) "onboarding" else "game"

    NavHost(navController = nav, startDestination = start) {
        composable("onboarding") { OnboardingScreen(onDone = { nav.navigate("game") }) }
        composable("game") { GameScreen(
            navigateToSettings = { nav.navigate("settings") },
            navigateToMultiplayer = { nav.navigate("multiplayer") },
            navigateToRoundComplete = { _ -> nav.navigate("roundcomplete") }
        ) }
        composable("settings") { SettingsScreen(onBack = { nav.popBackStack() }) }
        composable("multiplayer") { MultiplayerScreen(onBack = { nav.popBackStack() }) }
        composable("roundcomplete") { RoundCompleteScreen(onBackToGame = { nav.popBackStack("game", false) }) }
    }
}
