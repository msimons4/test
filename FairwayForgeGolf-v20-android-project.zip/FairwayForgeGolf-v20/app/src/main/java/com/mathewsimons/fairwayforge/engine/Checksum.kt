package com.mathewsimons.fairwayforge.engine

object Checksum {
    fun fromState(x: Float, y: Float, vx: Float, vy: Float): Int {
        var c = 1469598107
        fun mix(v: Int){ c = (c xor v) * 16777619 }
        mix((x/10f).toInt()); mix((y/10f).toInt()); mix((vx/10f).toInt()); mix((vy/10f).toInt())
        return c
    }
}
