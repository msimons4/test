package com.mathewsimons.fairwayforge.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun GameScreen(
    navigateToSettings: () -> Unit,
    navigateToMultiplayer: () -> Unit,
    navigateToRoundComplete: (String) -> Unit
) {
    var showStart by remember { mutableStateOf(true) }
    var holesToPlay by remember { mutableStateOf(9) }
    var holeIndex by remember { mutableStateOf(0) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Fairway Forge Golf") },
            actions = {
                TextButton(onClick = navigateToSettings) { Text("Settings") }
                Spacer(Modifier.width(8.dp))
                TextButton(onClick = navigateToMultiplayer) { Text("Multiplayer") }
            }
        )
    }) { padding ->
        Box(Modifier.fillMaxSize().padding(padding).background(Color(0xFFBDE0FF))) {
            // Simple stylized course background
            Canvas(Modifier.fillMaxSize().padding(12.dp)) {
                val w = size.width; val h = size.height
                drawRect(Color(0xFF81C784), topLeft = Offset(0f, h*0.4f), size = androidx.compose.ui.geometry.Size(w, h*0.6f))
            }

            Column(Modifier.align(Alignment.BottomCenter).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Hole ${holeIndex+1} / ${holesToPlay}")
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    if (holeIndex + 1 >= holesToPlay) {
                        navigateToRoundComplete("local")
                    } else {
                        holeIndex += 1
                    }
                }) { Text("Finish Hole") }
            }
        }

        StartRoundDialog(show = showStart, onDismiss = { showStart = false }, onStart = { n -> holesToPlay = n; showStart = false })
    }
}
