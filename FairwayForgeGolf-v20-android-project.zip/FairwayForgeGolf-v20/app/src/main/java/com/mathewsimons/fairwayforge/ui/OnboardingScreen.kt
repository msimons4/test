package com.mathewsimons.fairwayforge.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    var page by remember { mutableStateOf(0) }
    val titles = listOf("Aim & Swing","Wind & Clubs","Spin & Tempo","Multiplayer")
    val bodies = listOf(
        "Drag to aim. Use the swing meter to set backswing and strike on target.",
        "Wind affects flight; pick the right club for distance and height.",
        "Adjust Fade/Draw and Side Spin; swipe in the air to tweak spin.",
        "Create a room, share the code, and take alternating shots."
    )
    Scaffold(topBar = { TopAppBar(title = { Text("Tutorial") }) },
        bottomBar = {
            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = onDone) { Text("Skip") }
                Button(onClick = { if (page<3) page++ else onDone() }) { Text(if (page<3) "Next" else "Start") }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(titles[page], style = MaterialTheme.typography.headlineSmall)
            Text(bodies[page])
            Spacer(Modifier.height(180.dp))
        }
    }
}
